package uy.edu.ucu.aed;

/*
 * NO LICENCE 
 * Author: Ing. Agustin Paredes
 */

import java.util.Collection;
import java.util.LinkedList;


/**
 *
 * @author agustinp
 */
public class TMedidor
{
    public TDato obtenerMayorMedicion(TDato[] datos)
    {
        throw new UnsupportedOperationException("Método no implementado :(");
    }


}
