package uy.edu.ucu.aed;

import java.util.Collection;
import java.util.Map;

public interface IGrafoNoDirigido { }
