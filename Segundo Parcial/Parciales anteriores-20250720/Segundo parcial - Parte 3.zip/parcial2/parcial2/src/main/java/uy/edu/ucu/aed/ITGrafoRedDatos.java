package uy.edu.ucu.aed;

/*
 * NO LICENCE 
 * Author: Ing. Agustin Paredes
 */

/**
 *
 * @author agustinp
 */
public interface ITGrafoRedDatos 
{

    /**
     * 
     * @return 
     */
    public boolean conectados(Comparable a, Comparable b);
}
