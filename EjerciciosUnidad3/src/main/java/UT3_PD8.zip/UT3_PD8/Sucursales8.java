package UT3_PD8;

public class Sucursales8 {
    String direccion;

    public Sucursales8(String direccion) {
        this.direccion = direccion;
    }

    public String getDireccion() {
        return direccion;
    }
}
