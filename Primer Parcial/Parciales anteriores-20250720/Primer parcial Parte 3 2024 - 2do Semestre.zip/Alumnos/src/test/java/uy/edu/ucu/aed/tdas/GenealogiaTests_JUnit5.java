package uy.edu.ucu.aed.tdas;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


class GenealogiaTests_JUnit5 {


    @BeforeEach
    void init() {
        // TODO: inicialización para cada método de test si es necesario
    }

    @Test
    void unMetodoDeTest() {
        fail("No implementado aún");
    }
}
