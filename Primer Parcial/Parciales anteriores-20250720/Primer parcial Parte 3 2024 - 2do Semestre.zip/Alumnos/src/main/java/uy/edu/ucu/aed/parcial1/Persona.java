package uy.edu.ucu.aed.parcial1;

public class Persona {
    String nombre;

    public Persona(String nombre) {
        this.nombre = nombre;
    }
}
