package uy.edu.ucu.aed.parcial1;

public class Main {
    public static void main(String[] args) {
        // Crear personas
        // TODO: Crear las personas necesarias para el árbol genealógico

        // Crear árbol genealógico
        // TODO: Crear el árbol genealógico como se indica en el enunciado

        // Calcular parentescos
        // TODO: Realizar los cálculos de parentesco entre las personas que se indican en el enunciado

        // Emitir archivo de salida
        // TODO: Emitir el archivo de salida (Resultados.txt) con los resultados de los cálculos de parentesco
    }
}
