package uy.edu.ucu.aed.parcial1;

import uy.edu.ucu.aed.tdas.IElementoAB;

public class Genealogia {
    /**
     * Calcula el parentesco entre dos personas en un árbol genealógico.
     * 
     * @param raiz     Nodo raíz del árbol.
     * @param persona1 Nodo que representa a la primera persona.
     * @param persona2 Nodo que representa a la segunda persona.
     * @return ResultadoParentesco con los grados de parentesco y el tipo (consanguinidad o político).
     */
    public static ResultadoParentesco calcularParentesco(IElementoAB<Persona> raiz, IElementoAB<Persona> persona1, IElementoAB<Persona> persona2) {
        throw new UnsupportedOperationException("Método no implementado");
    }
}
