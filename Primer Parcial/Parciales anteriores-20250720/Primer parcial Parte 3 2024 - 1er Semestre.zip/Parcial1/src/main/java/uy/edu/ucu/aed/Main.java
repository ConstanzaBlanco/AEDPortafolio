package uy.edu.ucu.aed;

public class Main 
{
    public static void main( String[] args )
    {
        // Cargar el árbol a partir del archivo
        // Invocar el método solicitado
        // Mostrar por consola el reusltado
        
        System.out.println( "Change me!" );
    }
}
