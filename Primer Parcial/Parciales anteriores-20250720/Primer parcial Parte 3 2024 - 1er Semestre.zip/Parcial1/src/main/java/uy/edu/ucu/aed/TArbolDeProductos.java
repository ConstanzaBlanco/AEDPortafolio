package uy.edu.ucu.aed;

public class TArbolDeProductos extends TArbolBB<Producto> {
    
}
