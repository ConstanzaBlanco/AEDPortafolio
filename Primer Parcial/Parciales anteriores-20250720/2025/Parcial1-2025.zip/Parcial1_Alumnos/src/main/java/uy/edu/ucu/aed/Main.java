package uy.edu.ucu.aed;

import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.parcial.CatalogoPeliculasAVL;
import uy.edu.ucu.aed.utils.ManejadorArchivosGenerico;

/**
 * En esta clase se debe realizar la carga de los datos en la estructura, las búsquedas solicitadas y la escritura de los resultados en el archivo de texto.
 */
public class Main 
{
    public static void main(String[] args)
    {
        // Leer archivo Pelis.txt
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/main/java/uy/edu/ucu/aed/Pelis.txt");

        // Crear catálogo de películas (internamente usa un árbol AVL)
        CatalogoPeliculas catalogo = new CatalogoPeliculasAVL();

        // Cargar películas al catálogo
        for (String linea : lineas) {
            // Cargar la línea (una película) en el catálogo
        }

        // Búsqueda por puntaje: [6.0, 8.0]


        // Búsqueda por puntaje: solo máximo (<= 5.0)

        // Búsqueda por puntaje: solo mínimo (>= 7.5)

        // Búsqueda por género: "Romance"

        // Escribir resultados en archivo "src/main/java/uy/edu/ucu/aed/ResultadoBusquedas.txt"
    }
}
