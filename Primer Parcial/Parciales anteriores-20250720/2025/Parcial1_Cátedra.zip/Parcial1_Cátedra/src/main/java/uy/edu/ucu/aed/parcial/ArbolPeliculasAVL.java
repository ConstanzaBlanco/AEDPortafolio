package uy.edu.ucu.aed.parcial;

import uy.edu.ucu.aed.tdas.ArbolAVL;
import uy.edu.ucu.aed.tdas.ElementoAB;
import uy.edu.ucu.aed.tdas.IElementoAB;
import uy.edu.ucu.aed.modelo.Pelicula;

@SuppressWarnings("rawtypes")
/**
 * Clase que representa un árbol AVL de películas.
 * Esta clase extiende la clase ArbolAVL y define un nodo específico para películas.
 */
public class ArbolPeliculasAVL extends ArbolAVL<Pelicula> {
    @Override
    protected IElementoAB<Pelicula> crearNodo(Comparable etiqueta, Pelicula unDato) {
        return new NodoPelicula(etiqueta, unDato);
    }

    /**
     * Método que busca películas por genero en el árbol.
     * @param genero Género de la película a buscar.
     * @return Lista ordenada de películas que cumplen con el género
     */
    ListaOrdenada<Pelicula> buscarPorGenero(String genero) {
        ListaOrdenada<Pelicula> resultado = new ListaOrdenada<Pelicula>();

        if (raiz != null) {
            ((NodoPelicula) raiz).buscarPorGenero(genero, resultado);
        }

        return resultado;
    }

    /**
     * Método que busca películas por puntaje en el árbol.
     * @param minimo Puntaje mínimo (incluido).
     * @param maximo Puntaje máximo (incluido).
     * @return Lista ordenada de películas que cumplen con el rango de puntaje.
     */
    ListaOrdenada<Pelicula> buscarPorPuntaje(Float minimo, Float maximo) {
        ListaOrdenada<Pelicula> resultado = new ListaOrdenada<Pelicula>();

        if (raiz != null) {
            ((NodoPelicula) raiz).buscarPorPuntaje(minimo, maximo, resultado);
        }

        return resultado;
    }

    /**
     * Clase interna que representa un nodo de película en el árbol.
     * Extiende la clase ElementoAB para almacenar películas y permite búsquedas específicas.  
     */    
    private class NodoPelicula extends ElementoAB<Pelicula> {
        /**
         * Constructor del nodo de película.
         * @param etiqueta Clave o etiqueta del nodo.
         * @param datos Datos de la película a almacenar.
         */
        public NodoPelicula(Comparable etiqueta, Pelicula datos) {
            super(etiqueta, datos);
        }

        /**
         * Método que busca películas por puntaje en el árbol.
         * @param minimo Puntaje mínimo (incluido). Si es null, no se aplica mínimo.
         * @param maximo Puntaje máximo (incluido). Si es null, no se aplica máximo.
         * @param resultado Lista ordenada de películas que cumplen con el rango de puntaje.
         */
        public void buscarPorPuntaje(Float minimo, Float maximo, ListaOrdenada<Pelicula> resultado) {
            Pelicula pelicula = getDatos();

            float puntaje = pelicula.getPuntaje();

            // Verifica si el puntaje de la película está dentro del rango especificado
            boolean mayorMin = (minimo == null) || (puntaje >= minimo);
            boolean menorMax = (maximo == null) || (puntaje <= maximo);
            
            // El chequeo de puntaje se realiza por diferencia e igualdad para incluir los extremos del intervalo
            if (minimo == null || puntaje >= minimo) {
                // Si el hijo izquierdo no es nulo, busca en el subárbol izquierdo
                // para encontrar películas con puntajes mayores al mínimo
                if (getHijoIzq() != null)
                    ((NodoPelicula) getHijoIzq()).buscarPorPuntaje(minimo, maximo, resultado);
            }
            
            // Si la película cumple con el rango de puntaje, se agrega a la lista de resultados
            if (mayorMin && menorMax) {
                resultado.insertar(pelicula, pelicula.getAnio());
            }
            
            if (maximo == null || puntaje <= maximo) {
                // Si el hijo derecho no es nulo, busca en el subárbol derecho
                // para encontrar películas con puntajes menores al máximo
                if (getHijoDer() != null)
                    ((NodoPelicula) getHijoDer()).buscarPorPuntaje(minimo, maximo, resultado);
            }
        }

        /**
         * Método que busca películas por género en el árbol.
         * @param genero Género de la película a buscar.
         * @param resultado Lista ordenada de películas que cumplen con el género.
         */
        public void buscarPorGenero(String genero, ListaOrdenada<Pelicula> resultado) {
            if (getHijoIzq() != null)
                ((NodoPelicula) getHijoIzq()).buscarPorGenero(genero, resultado);
            if (getDatos().getGenero().equalsIgnoreCase(genero)) {
                resultado.insertar(getDatos(), getDatos().getAnio());
            }
            if (getHijoDer() != null)
                ((NodoPelicula) getHijoDer()).buscarPorGenero(genero, resultado);
        }
    }
}
