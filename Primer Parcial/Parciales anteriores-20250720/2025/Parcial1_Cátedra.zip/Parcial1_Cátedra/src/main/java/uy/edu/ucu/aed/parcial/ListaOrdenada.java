package uy.edu.ucu.aed.parcial;

import uy.edu.ucu.aed.tdas.Lista;

@SuppressWarnings({"rawtypes", "unchecked"})
/**
 * Clase que representa una lista ordenada genérica.
 * El orden se define por la clave (Comparable) asociada a cada elemento.
 */
public class ListaOrdenada<T> extends Lista<T> {

    @Override
    public boolean insertar(T dato, Comparable clave) {
        Nodo<T> nuevo = new Nodo<>(clave, dato);
        if (primero == null || primero.etiqueta.compareTo(clave) > 0) {
            nuevo.siguiente = primero;
            primero = nuevo;
            return true;
        }
        Nodo<T> actual = primero;
        while (actual.siguiente != null && actual.siguiente.etiqueta.compareTo(clave) <= 0) {
            actual = actual.siguiente;
        }
        nuevo.siguiente = actual.siguiente;
        actual.siguiente = nuevo;
        return true;
    }
}
