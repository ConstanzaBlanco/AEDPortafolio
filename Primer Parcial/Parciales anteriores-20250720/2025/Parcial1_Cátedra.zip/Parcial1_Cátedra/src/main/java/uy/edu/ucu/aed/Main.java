package uy.edu.ucu.aed;

import uy.edu.ucu.aed.modelo.Pelicula;
import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.parcial.CatalogoPeliculasAVL;
import uy.edu.ucu.aed.tdas.ILista;
import uy.edu.ucu.aed.utils.ManejadorArchivosGenerico;

/**
 * En esta clase se debe realizar la carga de los datos en la estructura, las búsquedas solicitadas y la escritura de los resultados en el archivo de texto.
 */
public class Main 
{
    public static void main(String[] args)
    {
        // Leer archivo Pelis.txt
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/main/java/uy/edu/ucu/aed/Pelis.txt");

        // Crear catálogo de películas (internamente usa un árbol AVL)
        CatalogoPeliculas catalogo = new CatalogoPeliculasAVL();

        // Cargar películas al catálogo
        for (String linea : lineas) {
            String[] partes = linea.split(";");

            // Validar que la línea tenga el formato correcto
            if (partes.length != 4) continue;
            
            int anio = Integer.parseInt(partes[0]);
            String titulo = partes[1];
            String genero = partes[2];
            float puntaje = Float.parseFloat(partes[3]);
            
            Pelicula pelicula = new Pelicula(titulo, anio, genero, puntaje);
            catalogo.insertarPelicula(pelicula);
        }

        // StringBuilder para almacenar la salida que se va a escribir en el archivo
        StringBuilder salida = new StringBuilder();

        // Búsqueda por puntaje: [6.0, 8.0]
        salida.append("Películas con puntaje entre 6.0 y 8.0:\n");
        System.out.println("Películas con puntaje entre 6.0 y 8.0:");
        ILista<Pelicula> porPuntaje = catalogo.buscarPorPuntaje(6.0f, 8.0f);
        imprimirPeliculas(porPuntaje, salida);

        // Búsqueda por puntaje: solo máximo (<= 5.0)
        salida.append("\nPelículas con puntaje menor o igual a 5.0:\n");
        System.out.println("\nPelículas con puntaje menor o igual a 5.0:");
        ILista<Pelicula> porPuntajeMax = catalogo.buscarPorPuntaje(null, 5.0f);
        imprimirPeliculas(porPuntajeMax, salida);

        // Búsqueda por puntaje: solo mínimo (>= 7.5)
        salida.append("\nPelículas con puntaje mayor o igual a 7.5:\n");
        System.out.println("\nPelículas con puntaje mayor o igual a 7.5:");
        ILista<Pelicula> porPuntajeMin = catalogo.buscarPorPuntaje(7.5f, null);
        imprimirPeliculas(porPuntajeMin, salida);

        // Búsqueda por género: "Romance"
        salida.append("\nPelículas del género Romance:\n");
        System.out.println("\nPelículas del género Romance:");
        ILista<Pelicula> porGenero = catalogo.buscarPorGenero("Romance");
        imprimirPeliculas(porGenero, salida);

        // Escribir resultados en archivo
        ManejadorArchivosGenerico.escribirArchivo("src/main/java/uy/edu/ucu/aed/ResultadoBusquedas.txt", salida.toString().split("\n"));
    }

    /**
     * Método que imprime las películas de una lista y las agrega a un StringBuilder.
     * @param listaPeliculas Lista de películas a imprimir.
     * @param salida StringBuilder donde se almacenará la salida.
     */
    private static void imprimirPeliculas(ILista<Pelicula> listaPeliculas, StringBuilder salida) {
        // Imprime cada película en la lista usando for-each
        for (Pelicula p : listaPeliculas) {
            if (p != null) {
                String linea = p.getAnio() + " - " + p.getTitulo() + " - " + p.getGenero() + " - " + p.getPuntaje();
                System.out.println(linea);
                
                salida.append(linea).append("\n");
            }
        }
    }
}
