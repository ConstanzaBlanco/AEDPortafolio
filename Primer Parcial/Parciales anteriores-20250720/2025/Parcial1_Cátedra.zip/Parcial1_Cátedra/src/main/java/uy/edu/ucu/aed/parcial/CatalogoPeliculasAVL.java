package uy.edu.ucu.aed.parcial;

import uy.edu.ucu.aed.tdas.ILista;
import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.modelo.ClavePelicula;
import uy.edu.ucu.aed.modelo.Pelicula;

/**
 * Clase que representa un catálogo de películas utilizando un árbol AVL.
 * Permite insertar películas y realizar búsquedas por puntaje y género.
 */
public class CatalogoPeliculasAVL implements CatalogoPeliculas {
    /**
     * Árbol AVL que almacena las películas, ordenadas por puntaje y título.
     */
    private ArbolPeliculasAVL arbolPorPuntaje;

    /**
     * Constructor de la clase CatalogoPeliculasAVL.
     * Inicializa el árbol AVL para almacenar las películas.
     */
    public CatalogoPeliculasAVL() {
        this.arbolPorPuntaje = new ArbolPeliculasAVL();
    }

    @Override
    public void insertarPelicula(Pelicula pelicula) {
        ClavePelicula clave = new ClavePelicula(pelicula.getPuntaje(), pelicula.getTitulo());
        arbolPorPuntaje.insertar(clave, pelicula);
    }

    @Override
    public ILista<Pelicula> buscarPorPuntaje(Float minimo, Float maximo) {
        return arbolPorPuntaje.buscarPorPuntaje(minimo, maximo);
    }

    @Override
    public ILista<Pelicula> buscarPorGenero(String genero) {
        return arbolPorPuntaje.buscarPorGenero(genero);
    }
}