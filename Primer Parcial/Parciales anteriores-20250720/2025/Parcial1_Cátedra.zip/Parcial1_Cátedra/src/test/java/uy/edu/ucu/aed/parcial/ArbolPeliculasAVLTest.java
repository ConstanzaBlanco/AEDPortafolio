package uy.edu.ucu.aed.parcial;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uy.edu.ucu.aed.modelo.Pelicula;
import uy.edu.ucu.aed.modelo.ClavePelicula;
import uy.edu.ucu.aed.tdas.ILista;

import static org.junit.jupiter.api.Assertions.*;

class ArbolPeliculasAVLTest {

    private ArbolPeliculasAVL arbol;
    private Pelicula p1, p2, p3, p4, p5;

    @BeforeEach
    void setUp() {
        arbol = new ArbolPeliculasAVL();
        p1 = new Pelicula("A", 2000, "Accion", 7.5f);
        p2 = new Pelicula("B", 2005, "Romance", 8.0f);
        p3 = new Pelicula("C", 2010, "Accion", 5.0f);
        p4 = new Pelicula("D", 2008, "Comedia", 9.2f);
        p5 = new Pelicula("E", 2005, "Romance", 4.5f);

        arbol.insertar(new ClavePelicula(p1.getPuntaje(), p1.getTitulo()), p1);
        arbol.insertar(new ClavePelicula(p2.getPuntaje(), p2.getTitulo()), p2);
        arbol.insertar(new ClavePelicula(p3.getPuntaje(), p3.getTitulo()), p3);
        arbol.insertar(new ClavePelicula(p4.getPuntaje(), p4.getTitulo()), p4);
        arbol.insertar(new ClavePelicula(p5.getPuntaje(), p5.getTitulo()), p5);
    }

    /**
     * Testea la búsqueda de películas por género en el árbol AVL.
     * Se espera que devuelva solo las películas del género "Romance".
     */
    @Test
    void testBuscarPorGenero() {
        ILista<Pelicula> romance = arbol.buscarPorGenero("Romance");
        assertEquals(2, romance.cantElementos());
        for (Pelicula p : romance) {
            assertEquals("Romance", p.getGenero());
        }
    }

    /**
     * Testea la búsqueda de películas por puntaje en el árbol AVL.
     * Se espera que devuelva solo las películas cuyo puntaje esté entre 5.0 y 8.0 inclusive.
     */
    @Test
    void testBuscarPorPuntaje() {
        ILista<Pelicula> rango = arbol.buscarPorPuntaje(5.0f, 8.0f);
        assertEquals(3, rango.cantElementos());
        for (Pelicula p : rango) {
            assertTrue(p.getPuntaje() >= 5.0f && p.getPuntaje() <= 8.0f);
        }
    }

    /**
     * Testea la búsqueda de películas por un género inexistente en el árbol AVL.
     * Se espera que devuelva una lista vacía.
     */
    @Test
    void testBuscarPorGeneroVacio() {
        ILista<Pelicula> terror = arbol.buscarPorGenero("Terror");
        assertEquals(0, terror.cantElementos());
    }
}
