package uy.edu.ucu.aed.parcial;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uy.edu.ucu.aed.modelo.Pelicula;

import static org.junit.jupiter.api.Assertions.*;

class ListaOrdenadaTest {

    private ListaOrdenada<Pelicula> lista;
    private Pelicula p1, p2, p3, p4, p5;

    @BeforeEach
    void setUp() {
        lista = new ListaOrdenada<>();
        p1 = new Pelicula("A", 2000, "Accion", 7.5f);
        p2 = new Pelicula("B", 2005, "Romance", 8.0f);
        p3 = new Pelicula("C", 2010, "Accion", 5.0f);
        p4 = new Pelicula("D", 2008, "Comedia", 9.2f);
        p5 = new Pelicula("E", 2005, "Romance", 4.5f);

        lista.insertar(p1, p1.getAnio());
        lista.insertar(p2, p2.getAnio());
        lista.insertar(p3, p3.getAnio());
        lista.insertar(p4, p4.getAnio());
        lista.insertar(p5, p5.getAnio());
    }

    /**
     * Testea que la inserción en la lista ordenada mantenga el orden por año ascendente.
     * Se recorre la lista y se verifica que cada elemento tenga un año mayor o igual al anterior.
     */
    @Test
    void testInsertarOrdenado() {
        int prev = Integer.MIN_VALUE;
        for (Pelicula p : lista) {
            assertTrue(p.getAnio() >= prev);
            prev = p.getAnio();
        }
    }

    /**
     * Testea la búsqueda y eliminación en la lista ordenada.
     * Se verifica que buscar por año devuelve la película correcta, que eliminar funciona,
     * y que luego de eliminar, la búsqueda devuelve null.
     */
    @Test
    void testBuscarYEliminar() {
        assertNotNull(lista.buscar(p1.getAnio()));
        assertTrue(lista.eliminar(p1.getAnio()));
        assertNull(lista.buscar(p1.getAnio()));
    }

    /**
     * Testea la cantidad de elementos y el método esVacia de la lista ordenada.
     * Se eliminan todos los elementos y se verifica que la lista quede vacía.
     */
    @Test
    void testCantElementosYVacia() {
        assertEquals(5, lista.cantElementos());
        lista.eliminar(p1.getAnio());
        lista.eliminar(p2.getAnio());
        lista.eliminar(p3.getAnio());
        lista.eliminar(p4.getAnio());
        lista.eliminar(p5.getAnio());
        assertTrue(lista.esVacia());
    }
}
