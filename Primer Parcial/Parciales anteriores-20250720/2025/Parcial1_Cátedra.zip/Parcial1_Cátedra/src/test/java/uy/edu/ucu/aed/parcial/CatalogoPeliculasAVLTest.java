package uy.edu.ucu.aed.parcial;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uy.edu.ucu.aed.modelo.Pelicula;
import uy.edu.ucu.aed.modelo.CatalogoPeliculas;
import uy.edu.ucu.aed.tdas.ILista;

import static org.junit.jupiter.api.Assertions.*;

class CatalogoPeliculasAVLTest {

    private CatalogoPeliculas catalogo;
    private Pelicula p1, p2, p3, p4, p5;

    @BeforeEach
    void setUp() {
        catalogo = new CatalogoPeliculasAVL();
        p1 = new Pelicula("A", 2000, "Accion", 7.5f);
        p2 = new Pelicula("B", 2005, "Romance", 8.0f);
        p3 = new Pelicula("C", 2010, "Accion", 5.0f);
        p4 = new Pelicula("D", 2008, "Comedia", 9.2f);
        p5 = new Pelicula("E", 2005, "Romance", 4.5f);

        catalogo.insertarPelicula(p1);
        catalogo.insertarPelicula(p2);
        catalogo.insertarPelicula(p3);
        catalogo.insertarPelicula(p4);
        catalogo.insertarPelicula(p5);
    }

    /**
     * Testea la búsqueda de películas por género en el catálogo.
     * Se espera que devuelva solo las películas del género "Romance".
     */
    @Test
    void testBuscarPorGenero() {
        ILista<Pelicula> romance = catalogo.buscarPorGenero("Romance");
        assertEquals(2, romance.cantElementos());
        for (Pelicula p : romance) {
            assertEquals("Romance", p.getGenero());
        }
    }

    /**
     * Testea la búsqueda de películas por puntaje en el catálogo.
     * Se espera que devuelva solo las películas cuyo puntaje esté entre 5.0 y 8.0 inclusive.
     */
    @Test
    void testBuscarPorPuntajeRango() {
        ILista<Pelicula> rango = catalogo.buscarPorPuntaje(5.0f, 8.0f);
        assertEquals(3, rango.cantElementos());
        for (Pelicula p : rango) {
            assertTrue(p.getPuntaje() >= 5.0f && p.getPuntaje() <= 8.0f);
        }
    }

    /**
     * Testea la búsqueda de películas por puntaje mínimo en el catálogo.
     * Se espera que devuelva solo las películas cuyo puntaje sea mayor o igual a 8.0.
     */
    @Test
    void testBuscarPorPuntajeSoloMinimo() {
        ILista<Pelicula> min = catalogo.buscarPorPuntaje(8.0f, null);
        assertEquals(2, min.cantElementos());
        for (Pelicula p : min) {
            assertTrue(p.getPuntaje() >= 8.0f);
        }
    }

    /**
     * Testea la búsqueda de películas por puntaje máximo en el catálogo.
     * Se espera que devuelva solo las películas cuyo puntaje sea menor o igual a 5.0.
     */
    @Test
    void testBuscarPorPuntajeSoloMaximo() {
        ILista<Pelicula> max = catalogo.buscarPorPuntaje(null, 5.0f);
        assertEquals(2, max.cantElementos());
        for (Pelicula p : max) {
            assertTrue(p.getPuntaje() <= 5.0f);
        }
    }

    /**
     * Testea la búsqueda de películas por un género inexistente en el catálogo.
     * Se espera que devuelva una lista vacía.
     */
    @Test
    void testBuscarPorGeneroVacio() {
        ILista<Pelicula> terror = catalogo.buscarPorGenero("Terror");
        assertEquals(0, terror.cantElementos());
    }

    /**
    * Verifica que buscarPorPuntaje devuelve todas las películas
    * cuando todas tienen el mismo puntaje, aunque estén en distintas ramas del árbol.
    */    
    @Test
    void testBuscarPorPuntaje_TodasMismoPuntaje() {
        CatalogoPeliculas catalogo = new CatalogoPeliculasAVL();

        Pelicula p1 = new Pelicula("A", 2000, "Accion", 8.0f);
        Pelicula p2 = new Pelicula("B", 2005, "Romance", 8.0f);
        Pelicula p3 = new Pelicula("C", 2010, "Comedia", 8.0f);
        Pelicula p4 = new Pelicula("D", 2015, "Terror", 8.0f);

        catalogo.insertarPelicula(p1);
        catalogo.insertarPelicula(p2);
        catalogo.insertarPelicula(p3);
        catalogo.insertarPelicula(p4);

        ILista<Pelicula> resultado = catalogo.buscarPorPuntaje(8.0f, 8.0f);

        assertEquals(4, resultado.cantElementos());
    }
}
